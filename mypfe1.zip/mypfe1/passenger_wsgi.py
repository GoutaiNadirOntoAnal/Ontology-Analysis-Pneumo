import os
import sys

BASE_DIR = os.path.dirname(__file__)
sys.path.insert(0, BASE_DIR)

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mypfe.settings")

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()